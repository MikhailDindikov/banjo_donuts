import 'package:flutter/material.dart';

class KletkaModel1111 {
  late final Offset cenPositiondDon;

  late int xKDon;
  late int yKDon;

  KletkaModel1111();

  void generateP11o1211qqq212121221sKlD(bool aaaaaaas, int yDon) {
    xKDon = aaaaaaas == false ? 1 : 0;
    yKDon = yDon;
    cenPositiondDon = Offset((xKDon).toDouble(), (250 + yKDon).toDouble());
    final premS = false;
  }
}
